/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *Label;
    QLineEdit *lineEdit_URL;
    QLabel *label;
    QComboBox *comboBox_Payload;
    QLineEdit *lineEdit_CustomPayload;
    QPushButton *pushButton_Test;
    QLabel *label_2;
    QTextEdit *textEdit_Response;
    QCheckBox *checkBox_SaveLogs;
    QPushButton *pushButton_ExportLog;
    QPushButton *pushButton_DarkMode;
    QPushButton *pushButton_About;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(909, 796);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        Label = new QLabel(centralwidget);
        Label->setObjectName("Label");
        Label->setGeometry(QRect(0, 10, 91, 41));
        lineEdit_URL = new QLineEdit(centralwidget);
        lineEdit_URL->setObjectName("lineEdit_URL");
        lineEdit_URL->setGeometry(QRect(70, 20, 331, 31));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(10, 80, 131, 41));
        comboBox_Payload = new QComboBox(centralwidget);
        comboBox_Payload->setObjectName("comboBox_Payload");
        comboBox_Payload->setGeometry(QRect(130, 90, 101, 31));
        lineEdit_CustomPayload = new QLineEdit(centralwidget);
        lineEdit_CustomPayload->setObjectName("lineEdit_CustomPayload");
        lineEdit_CustomPayload->setEnabled(false);
        lineEdit_CustomPayload->setGeometry(QRect(250, 90, 251, 31));
        pushButton_Test = new QPushButton(centralwidget);
        pushButton_Test->setObjectName("pushButton_Test");
        pushButton_Test->setGeometry(QRect(130, 130, 131, 41));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(30, 350, 61, 51));
        textEdit_Response = new QTextEdit(centralwidget);
        textEdit_Response->setObjectName("textEdit_Response");
        textEdit_Response->setGeometry(QRect(100, 190, 741, 471));
        textEdit_Response->setReadOnly(true);
        textEdit_Response->setTextInteractionFlags(Qt::TextSelectableByKeyboard|Qt::TextSelectableByMouse);
        checkBox_SaveLogs = new QCheckBox(centralwidget);
        checkBox_SaveLogs->setObjectName("checkBox_SaveLogs");
        checkBox_SaveLogs->setGeometry(QRect(20, 690, 101, 41));
        pushButton_ExportLog = new QPushButton(centralwidget);
        pushButton_ExportLog->setObjectName("pushButton_ExportLog");
        pushButton_ExportLog->setEnabled(false);
        pushButton_ExportLog->setGeometry(QRect(100, 690, 111, 41));
        pushButton_DarkMode = new QPushButton(centralwidget);
        pushButton_DarkMode->setObjectName("pushButton_DarkMode");
        pushButton_DarkMode->setGeometry(QRect(724, 20, 111, 41));
        pushButton_About = new QPushButton(centralwidget);
        pushButton_About->setObjectName("pushButton_About");
        pushButton_About->setGeometry(QRect(820, 710, 75, 24));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 909, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        Label->setText(QCoreApplication::translate("MainWindow", "Target URL:", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "SQL Injection Payload", nullptr));
        pushButton_Test->setText(QCoreApplication::translate("MainWindow", "Test SQL Injection", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Response:", nullptr));
        checkBox_SaveLogs->setText(QCoreApplication::translate("MainWindow", "Save Logs", nullptr));
        pushButton_ExportLog->setText(QCoreApplication::translate("MainWindow", "Export Log", nullptr));
        pushButton_DarkMode->setText(QCoreApplication::translate("MainWindow", "Dark Mode", nullptr));
        pushButton_About->setText(QCoreApplication::translate("MainWindow", "About", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
